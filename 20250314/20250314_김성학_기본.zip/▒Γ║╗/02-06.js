function foodReport(name, age, ...favorites) {
  console.log(name + ',' + age);
  console.log(favorites);
}

foodReport('이몽룡', 20, '짜장면', '냉면', '불고기');
foodReport('홍길동', 20, '초밥');
