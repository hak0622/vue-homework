let name = '홍길동';
let age = 20;
let email = 'asd@naver.com';

let obj = [name, age, email];
console.log(obj);
