import getBase, { add } from './02-19.mjs';
console.log(add(4));
console.log(getBase());
