function hello(name) {
  console.log(`${name}님, 안녕하세요`);
}

hello('홍길동');

//npm uninstall ansi-colors (모듈 삭제)
// 모듈 삭제 후 수행 -> can not find 오류 발생
