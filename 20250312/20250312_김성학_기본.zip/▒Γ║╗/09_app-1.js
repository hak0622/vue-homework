const user = require('./07_user');
const hello = require('./08_hello');

console.log(user);
console.log(hello);

hello(user);
