const { user1, user2 } = require('./10_users-1');
const hello = require('./08_hello');
hello(user1);
hello(user2);
