import { hi as hello, goodbye as bye } from './greeting-1.mjs';

hello('홍길동');
bye('홍길동');
