const path = require('path');
console.log(`절대 경로:${__filename}`);

const dir = path.dirname(__filename);
console.log(`디렉토리 : ${dir}`);
