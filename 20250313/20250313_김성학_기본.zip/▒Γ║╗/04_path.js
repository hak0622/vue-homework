const path = require('path');

const ext = path.extname(__filename);
console.log(`파일 확장자:${ext}`);
