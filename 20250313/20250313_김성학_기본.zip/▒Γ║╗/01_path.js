const path = require('path');
const fullpath = path.join('some', 'work', 'ex.txt');
console.log(fullpath);
