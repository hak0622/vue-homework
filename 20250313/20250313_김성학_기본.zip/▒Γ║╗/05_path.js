const path = require('path');
const paredPath = path.parse(__filename);
console.log(paredPath);
